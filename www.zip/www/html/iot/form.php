<form action="includes/add.php" method="post">
	<input type="number" name="temp1">
	<input type="number" name="hum1">
	<input type="submit" value="Submit">
</form>
