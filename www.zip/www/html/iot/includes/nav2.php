<div id="nav2">
	<a href="includes/dayBefore.php">
		<div id="leftArrow"></div>
	</a>
	<div id="title">
		<p></p>
	</div>
	<a href="includes/dayAfter.php">
		<div id="rightArrow"></div>
	</a>
</div>
